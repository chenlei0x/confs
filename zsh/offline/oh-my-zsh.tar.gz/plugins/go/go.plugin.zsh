print -P "%F{yellow}The 'go' plugin is deprecated. Use the '%Ugolang%u' plugin instead.%f"

source "$ZSH/plugins/golang/golang.plugin.zsh"
