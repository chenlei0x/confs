gdb ./vmlinux -ex 'target remote :1234'
